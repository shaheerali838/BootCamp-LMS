import mongoose from "mongoose";

const teamMemberSchema = new mongoose.Schema(
  {
    teamName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
      required: true,
    },
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true,
    },
    joinedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true },
);

const TeamMember = mongoose.model("TeamMember", teamMemberSchema);
export default TeamMember;

import mongoose from "mongoose";

const teamProjectSchema = new mongoose.Schema(
  {
    teamName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
      required: true,
    },
    projectTitle: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true,
    },
    assignedDate: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true },
);

const TeamProject = mongoose.model("TeamProject", teamProjectSchema);
export default TeamProject;
